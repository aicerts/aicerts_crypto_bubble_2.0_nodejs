module.exports.Crypto = require('./cryptoModel');
module.exports.CryptoGraph = require("./cryptoGraphModel")
module.exports.cryptoImage = require("./cryptoImageModel")